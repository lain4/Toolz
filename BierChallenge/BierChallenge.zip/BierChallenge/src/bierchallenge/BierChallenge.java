/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bierchallenge;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

/**
 *
 * @author Männersahne
 */
public class BierChallenge extends Application {
    
    @Override
    public void start(Stage primaryStage) {
        
        
        Button btn = new Button();
        btn.setText("Zur zweiten Scene");
        
        Button back = new Button();
        back.setText("Zur ersten Scene");
        
        Group root = new Group();
        Group sub = new Group();
 
        root.getChildren().add(btn);
        sub.getChildren().add(back);

        Scene scene = new Scene(root, 300, 250,Color.GREEN);
        Scene subscene = new Scene(sub,300,250,Color.RED);
  

        btn.setOnAction((ActionEvent event) -> {
            if(event.getSource()==btn) primaryStage.setScene(subscene);
        });
        
        back.setOnAction((ActionEvent event) -> {
            if(event.getSource()==back) primaryStage.setScene(scene);
        });
        

        
        
        primaryStage.setTitle("Hello World!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */

    
}
