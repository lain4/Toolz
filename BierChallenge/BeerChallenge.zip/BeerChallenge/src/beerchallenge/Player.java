package beerchallenge;

import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.control.Label;
import javafx.scene.image.ImageView;
import javafx.scene.layout.BorderPane;


public class Player extends Entity{
    
        private final ImageView avatar;

        public Player(String name) {
            super(name);
            this.avatar = new ImageView("/images/cat.png");
        }

        public Player(String name, int drunk, int pong, int klim, int pHits, int kHits) {
            super(name, drunk, pong, klim, pHits, kHits);
            this.avatar = new ImageView("/images/cat.png");
        }

        public final ImageView getPic() {
            return avatar;
        }

        public final Group getAvatar() {
            Group g = new Group();
            BorderPane root = new BorderPane();
            root.setPrefWidth(20);
            root.setPrefHeight(20);
            Label drunk = new Label();
            drunk.textProperty().bind(Bindings.convert(beerDone));
            drunk.setAlignment(Pos.TOP_CENTER);
            
            root.setTop(new Label(getName()));
            root.setRight(drunk);
            root.setCenter(avatar);

            g.getChildren().add(root);
            return g;
        }

    
}
