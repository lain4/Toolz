package beerchallenge;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class GameState {
            private final Game[] games = new Game[7];
            private Team[] teams = new Team[4];
                        
            Player[] team = new Player[]{ new Player("Winnie"), 
                                                     new Player("mii"), 
                                                     new Player("Pups"), 
                                                     new Player("Miau")};
            Team team1 = new Team("Milchkrieger", team);
            Player[] team_ = new Player[]{ new Player("Ruu"), 
                                                     new Player("rawu"), 
                                                     new Player("loooooglgo"), 
                                                     new Player("rasdasd")};
            Team team2 = new Team("Tigermilch", team_);
            
           
            static Game game;

            public GameState(int index) {
                game = new Pong(team1, team2);
            }
            
            public GameState(boolean turn, int sc1, int sc2, int index) {
                game = games[index];
                game.setTurn(turn);
                game.setScore1(sc1);
                game.setScore2(sc2);
            }
            


}
