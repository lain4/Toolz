/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beerchallenge;

import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;

/**
 *
 * @author oem
 */
public class Pong extends Game{
    
        public Pong(Team team1, Team team2) {
            super(team1, team2);
        }
        
        @Override
        void run() {
            while(this.isPlayable()) {
                   
            }
        }
        
        @Override
        Parent showContent() {
            Group g = new Group();
            HBox hbox = new HBox();
            Button test = new Button("test");
            test.setOnAction(e -> System.out.println("test"));
            hbox.setPrefHeight(100);
            hbox.setPrefWidth(100);
            hbox.setStyle("-fx-background-color: green");
            hbox.getChildren().add(test);
            g.getChildren().add(hbox);
            return g;
        }
    
}