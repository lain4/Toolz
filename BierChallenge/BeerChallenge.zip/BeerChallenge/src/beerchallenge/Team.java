
package beerchallenge;

import java.util.Arrays;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Pos;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


public class Team {
        private final String name;
        private final Player[] team;
        private final IntegerProperty allDrunk;
        private final GridPane avatar;

        Team(String name, Player[] team) {
            this.name = name;
            this.team = team;
            this.allDrunk = new SimpleIntegerProperty(Arrays.stream(team)
                                                                                          .mapToInt(e -> e.getDrunk().intValue())
                                                                                          .sum());
            avatar = genGrid();
            avatar.setAlignment(Pos.TOP_CENTER);


        }
        
        private GridPane genGrid() {
                GridPane layout = new GridPane();
                Label drunk = new Label(allDrunk.intValue() + "");
                Label name = new Label(getName());
                layout.add(drunk, 0, 0);
                layout.add(name, 0, 1);
                layout.add(team[0].getAvatar(), 1, 0);
                layout.add(team[1].getAvatar(), 1, 1);
                layout.add(team[2].getAvatar(), 1, 2);
                layout.add(team[3].getAvatar(), 2, 2);
                layout.setAlignment(Pos.CENTER);
                return layout;
        }
        
        public final GridPane getTest() {
            GridPane test = new GridPane();
            Rectangle rect = new Rectangle(20, 30, Color.CHOCOLATE);
            Rectangle rect2 = new Rectangle(20, 30, Color.BURLYWOOD);
            test.add(rect, 0, 1);
            test.add(rect2, 0, 0);
            test.setAlignment(Pos.CENTER);
            return  test;
        }
        
        public final Player[] getMates() {
            return team;
        }
        
        public final GridPane getAvatar() {
            return avatar;
        }

        public final IntegerProperty getDrunk() {
            return allDrunk;
        }
        
        public final String getName() {
            return name;
        }
}
