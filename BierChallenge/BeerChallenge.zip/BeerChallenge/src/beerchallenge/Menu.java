/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beerchallenge;

import javafx.geometry.Insets;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.text.Text;

/**
 *
 * @author oem
 */
public class Menu extends Game{

    public Menu(Team first, Team sec) {
        super(first, sec);
    }
    
    @Override
    Parent showContent() {
            Group menu = new Group();
            FlowPane flow = new FlowPane();
            flow.setPadding(new Insets(80));
            flow.setVgap(100);
            flow.setHgap(100);
            flow.setPrefWrapLength(170);
            flow.setStyle("-fx-background-color: white;");

            ImageView pages[] = new ImageView[6];
            for (int i=0; i< 6; i++) {
                pages[i] = new ImageView("images/game_" + i + ".png");
                pages[i].setX(50);
                pages[i].setY(50);
            }

            //navigate to game
            pages[0].setOnMouseClicked(e -> System.out.println("hlp"));
            pages[1].setOnMouseClicked(e -> System.out.println("hlp"));
            pages[2].setOnMouseClicked(e -> System.out.println("hlp"));
            pages[3].setOnMouseClicked(e -> System.out.println("hlp"));
            pages[4].setOnMouseClicked(e -> System.out.println("hlp"));
            pages[5].setOnMouseClicked(e -> System.out.println("hlp"));

            flow.getChildren().addAll(pages);
            menu.getChildren().add(flow);
            return menu;
    }

    @Override
    void run() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
