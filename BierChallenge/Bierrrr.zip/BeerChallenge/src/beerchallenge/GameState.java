package beerchallenge;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;


public class GameState {
            private final Game[] games = new Game[7];
            static Game game;

            public GameState(int index) {
                game = new Pong(null, null);
            }
            
            public GameState(boolean turn, int sc1, int sc2, int index) {
                game = games[index];
                game.setTurn(turn);
                game.setScore1(sc1);
                game.setScore2(sc2);
            }

}
