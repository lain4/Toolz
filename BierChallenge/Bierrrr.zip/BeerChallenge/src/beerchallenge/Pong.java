/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beerchallenge;

import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.layout.HBox;

/**
 *
 * @author oem
 */
public class Pong extends Game{
    
        public Pong(Player[] team1, Player[] team2) {
            super(team1, team2);
        }
        
        @Override
        void run() {
            while(this.isPlayable()) {
                   
            }
        }
        
        @Override
        Parent showContent() {
            Group g = new Group();
            HBox hbox = new HBox();
            hbox.setPrefHeight(100);
            hbox.setPrefWidth(100);
            hbox.setStyle("-fx-background-color: green");
            g.getChildren().add(hbox);
            return g;
        }
    
}
