package beerchallenge;

import java.io.IOException;
import javafx.application.Application;
import javafx.beans.binding.Bindings;
import javafx.fxml.FXMLLoader;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.scene.layout.BorderPane;
import javafx.geometry.Pos;
import javafx.scene.Parent;
import javafx.scene.control.Label;
import javafx.scene.control.SplitPane;
import javafx.scene.image.ImageView;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class BierChallenge {
    
    Parent createContent() {
        GameState state = new GameState(6);
        Group g = new Group();
        BorderPane root = new BorderPane();
        Player p = new Player("Winnie");
        
        //CENTER/GAME
        FlowPane flow = new FlowPane();
        flow.setPadding(new Insets(80));
        flow.setVgap(100);
        flow.setHgap(100);
        flow.setPrefWrapLength(170);
        flow.setStyle("-fx-background-color: white;");
        
        ImageView pages[] = new ImageView[6];
        for (int i=0; i< 6; i++) {
            pages[i] = new ImageView("images/game_" + i + ".png");
            pages[i].setX(50);
            pages[i].setY(50);
        }
        
        //navigate to game
        pages[0].setOnMouseClicked(e -> root.setCenter(state.game.showContent()));
        pages[1].setOnMouseClicked(e -> root.setCenter(new Text("yeah")));
        pages[2].setOnMouseClicked(e -> root.setCenter(new Text("yeah")));
        pages[3].setOnMouseClicked(e -> root.setCenter(new Text("yeah")));
        pages[4].setOnMouseClicked(e -> root.setCenter(new Text("yeah")));
        pages[5].setOnMouseClicked(e -> root.setCenter(new Text("yeah")));
        
        flow.getChildren().addAll(pages);
        
        
        //TOP
        Label score1 = new Label();
        score1.textProperty().bind(Bindings.convert(state.game.getScore1()));
        score1.setTextFill(Color.RED);
        score1.setFont(Font.font("Comic Sans", FontWeight.BOLD, 35));
        
        Label score2 = new Label();
        score2.textProperty().bind(Bindings.convert(state.game.getScore2()));
        score2.setTextFill(Color.LIGHTBLUE);
        score2.setFont(Font.font("Comic Sans", FontWeight.BOLD, 35));
        
        HBox topBox = new HBox(20);
        topBox.setPrefHeight(65);
        topBox.getChildren().addAll(score1, score2);
        topBox.setAlignment(Pos.CENTER);
        topBox.setStyle("-fx-background-color: black");
        
        
        //LEFT
        SplitPane leftBox = new SplitPane();
        leftBox.setOrientation(Orientation.VERTICAL);
        
        Text sc_team1 = new Text("10");
        Text stat_team1 = new Text("38");
        Text sc_team2 = new Text("101010");
        Text stat_team2 = new Text("50");
        
        GridPane team1 = new GridPane();
        team1.add(sc_team1, 0, 0);
        team1.add(stat_team1, 1, 0);
        //team1.add(p.getAvatar(), 0, 1);
        team1.setPrefHeight(100);
        team1.setPrefWidth(150);
        team1.setHgap(10);
        team1.setVgap(30);
        team1.setAlignment(Pos.CENTER);
        GridPane team2 = new GridPane();
        team2.add(sc_team2, 0, 0);
        team2.add(stat_team2, 1, 0);
        team2.setPrefHeight(100);
        team2.setPrefWidth(150);
        team2.setAlignment(Pos.CENTER);
        team2.setHgap(10);
        team2.setVgap(30);
        
        leftBox.getItems().addAll(team1, team2);
        
        
        //RIGHT
        VBox rightBox = new VBox(40);
        rightBox.setStyle("-fx-background-color: royalblue"); 
        rightBox.setPadding(new Insets(10));
        
        Button nxt = new Button("End turn/Next");
        nxt.setOnAction(e -> { if (!state.game.getTurn())
                                                state.game.setScore1(1);
                                            else
                                                state.game.setScore2(1);
                                            state.game.endTurn();
                                          });
        nxt.setPrefHeight(40);
        Button bck = new Button("Back/Previous");
        bck.setOnAction(e -> System.out.println("mii"));
        bck.setPrefHeight(50);
        Button sav = new Button("Save/Pause");
        sav.setOnAction(e -> p.addBeer(1));
        sav.setPrefHeight(50);
        Button tSelect = new Button("Team selection");
        
        tSelect.setOnAction(e -> {
                        //Zur Teamauswahl
            Stage stage = (Stage) g.getScene().getWindow();
            //Teams team = new Teams();
            //String[] tmp = FXMLDocumentController.getNames(team.fields);

            //for(int i = 0; i < tmp.length; i++){
            //    team.fields[i].setText(tmp[0]);
            //}
            Scene scene = stage.getScene();
            try{
                scene.setRoot(FXMLLoader.load(getClass().getResource("FXMLDocument.fxml")));
            }catch(IOException exception){
                exception.printStackTrace();
            }
        });
        tSelect.setPrefHeight(50);
        Button gSelect = new Button("Game selection");
        gSelect.setOnAction(e -> root.setCenter(flow));
        gSelect.setPrefHeight(50);
        Button hlp = new Button("Help");
        hlp.setOnAction(e -> System.out.println("mii"));
        hlp.setPrefHeight(50);
        
        rightBox.getChildren().addAll(nxt, bck, sav, tSelect, gSelect, hlp);
        
        
        //BOT
        HBox botBox = new HBox();
        
        
        //ROOT MERGE
        root.setPrefWidth(800);
        root.setPrefHeight(600);   
        
        root.setCenter(flow);
        root.setTop(topBox);
        root.setLeft(leftBox);
        root.setRight(rightBox);
        root.setBottom(botBox);
        g.getChildren().add(root);
        
        return g;
    }  
    
}
