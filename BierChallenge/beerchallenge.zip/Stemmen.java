/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beerchallenge;

import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.layout.HBox;

/**
 *
 * @author Männersahne
 */
public class Stemmen extends Game {
    
    public Stemmen(Team t1, Team t2){
        super(t1, t2);
        this.type = Type.STEMMEN;
    }
    
    @Override
    void run() {
        while(this.isPlayable()) {
                
        }
    }
    
    @Override
    Parent showContent() {
        Group g = new Group();
        HBox hbox = new HBox();
        Button test = new Button("test");
        test.setOnAction(e -> { for(Player p : getT1())
                                    p.addBeer(1);
                                //Sample-Action (working)
                                });
        hbox.setPrefHeight(100);
        hbox.setPrefWidth(100);
        hbox.setStyle("-fx-background-color: green");
        hbox.getChildren().add(test);
        g.getChildren().add(hbox);
        return g;
        }
    
}
