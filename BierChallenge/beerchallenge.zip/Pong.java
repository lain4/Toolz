

package beerchallenge;

import javafx.beans.binding.Bindings;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Parent;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Region;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;


public class Pong extends Game{
    
        private final IntegerProperty streak = new SimpleIntegerProperty();
    
        public Pong(Team t1, Team t2) {
            super(t1, t2);
            this.type = Type.PONG;
        }
        
        @Override
        void run() {
            while(this.isPlayable()) {
                
            }
        }
        
        
        
        @Override
        Parent showContent() {
            Group g = new Group();
            VBox outer = new VBox(30);
            HBox upper = new HBox();
            
            upper.setPrefWidth(Region.USE_PREF_SIZE);
            streak.set(0);
            Button sub1 = new Button("add to " + getT1().get(0).getName());
            sub1.setMinWidth(Region.USE_PREF_SIZE);
            sub1.setOnAction(e -> { setScore1(streak.getValue());
                                                   streak.set(0);
                                        });
            sub1.setAlignment(Pos.TOP_LEFT);
            Button sub2 = new Button("add to " + getT2().get(0).getName());
            sub2.setMinWidth(Region.USE_PREF_SIZE);
            sub2.setOnAction(e -> { setScore2(streak.getValue());
                                                   streak.set(0);
                                        });
            sub1.setAlignment(Pos.TOP_RIGHT);
            upper.getChildren().addAll(sub1, sub2);
            outer.getChildren().add(upper);
                    
            for(int i = -3; i <= 3; i++) {
                HBox row = new HBox(20);
                row.setAlignment(Pos.CENTER);
                for(int j = Math.abs(i); j > 0; j--) {
                    Circle circle = new Circle(30, Color.RED);
                    circle.setOnMouseClicked(e -> { circle.setFill(Color.BLACK);
                                                                       streak.set(streak.getValue() + 1);
                                                            });
                    row.getChildren().add(circle);
                }
                outer.getChildren().add(row);
            }
            
            Label combo = new Label();
            combo.textProperty().bind(Bindings.convert(streak));
            combo.setTextFill(Color.RED);
            combo.setFont(Font.font("Arial", FontWeight.BOLD, 35));
            outer.getChildren().add(combo);
            Button test = new Button("test");        
            test.setOnAction(e -> { for(Player p : getT1())
                                        p.addBeer(1);
                                    //Sample-Action (working)
                                    });
            outer.setPrefSize(Region.USE_PREF_SIZE, Region.USE_PREF_SIZE);
            g.getChildren().add(outer);
            return g;
        }
    
}