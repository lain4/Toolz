/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package beerchallenge;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;


public class FXMLDocumentController implements Initializable {
    
    public static GameState STATE;
    
    
    @FXML
    public TextField t1,t2,t3,t4,t5,t6,
                     t1n1,t1n2,t1n3,t1n4,
                     t2n1,t2n2,t2n3,t2n4,
                     t3n1,t3n2,t3n3,t3n4,
                     t4n1,t4n2,t4n3,t4n4,
                     t5n1,t5n2,t5n3,t5n4,
                     t6n1,t6n2,t6n3,t6n4;
    
    @FXML 
    public AnchorPane an;
    
    @FXML
    public VBox v1,v2,v3,v4,v5,v6;
    
    @FXML
    private ComboBox<String> combi;
    
    
    /*public void setTextFields(){
        //t1 mit Inhalt aus GAME_STATE füllen
        //Teamanzahl
        Team[] tmp = BeerChallenge.GAME_STATE.teams;
        VBox[] boxes = {v1,v2,v3,v4,v5,v6};
        TextField[] teamnames ={t1,t2,t3,t4,t5,t6};
        System.out.println(tmp.length);
        
        v1.setVisible(true);
        //Unhiden, Teamnamen
        for(int x = 0; x < tmp.length; x++){
            
   
        }
        
        /*TextField[][] nameFields = {{t1,t2,t3,t4,t5,t6},
                                    {t1n1,t1n2,t1n3,t1n4},
                                    {t2n1,t2n2,t2n3,t2n4},
                                    {t3n1,t3n2,t3n3,t3n4},
                                    {t4n1,t4n2,t4n3,t4n4},
                                    {t5n1,t5n2,t5n3,t5n4},
                                    {t6n1,t6n2,t6n3,t6n4}};
        for(int i_ = 0; i < counter; i++){
            for(int j = 0; j < 4; j++){
                nameFields[i][j].setText(tmp[i_].team.get(j).name);

            }
        }

       //Auf nicht Editable setzen
    }*/
    
    
    @FXML
    private void toGame(ActionEvent event) throws IOException{
            
        BeerChallenge b = new BeerChallenge();
        
        Stage stage = (Stage) an.getScene().getWindow();
        Scene scene = stage.getScene();

        if(BeerChallenge.GAME_STATE.getTeam1()==null){
        
            TextField[] teamFields = {t1,t2,t3,t4,t5,t6};
            TextField[][] fields = {{t1n1,t1n2,t1n3,t1n4},
                            {t2n1,t2n2,t2n3,t2n4},
                            {t3n1,t3n2,t3n3,t3n4},
                            {t4n1,t4n2,t4n3,t4n4},
                            {t5n1,t5n2,t5n3,t5n4},
                            {t6n1,t6n2,t6n3,t6n4}};

            //Teamanzahl
            ArrayList<TextField> visibles = new ArrayList<>();
            for (TextField teamField : teamFields) {
                if (teamField.isVisible()) {
                    visibles.add(teamField);
                }
            }

            //Spielererstellung
            LinkedList<Team> teams = new LinkedList<>();
            Team tmp;

            for(int i = 0; i<visibles.size();i++){
                LinkedList<Player> mates = new LinkedList<>();
                for(int j = 0; j < 4; j++){
                    mates.add(new Player(fields[i][j].getText()));
                }
                tmp = new Team(visibles.get(i).getText(),mates);
                teams.add(tmp);
            }
            //GameState füllen
            BeerChallenge.GAME_STATE = new GameState(teams,0,1);
        }
        
        BeerChallenge bier = new BeerChallenge();
        //GameState übernehmen
        scene.setRoot(bier.createContent(BeerChallenge.GAME_STATE));
    }

 
    
    
    @FXML
    private void addTeam(ActionEvent event) throws IOException {
        VBox[] textboxes = {v1,v2,v3,v4,v5,v6};
        String s = combi.getValue();
        for(VBox v: textboxes) v.setVisible(false);
        for(int i = 0; i<Integer.valueOf(s);i++){
            textboxes[i].setVisible(true);
        }
    }
    
    @FXML
    private void close(){
        System.exit(0);
    }
    
    public boolean initializeGameState(GameState state){
        //catch teamnames, teamspieler und irgendwo speichern
        if(state.getTeam1()==null){
 
        return true;
        }else{
             BeerChallenge.GAME_STATE = state;
             return false;
               
        }
      
        
    }



    @Override
    public void initialize(URL url, ResourceBundle rb) { 
    }
    
    
}
